OUTDATED (If someone wants to update then please do)

#Missing textures#

-=Blocks=-
bed
flower paeonia //1 tall
sliver glass, concrete //Don't actually think exists in game
tall grass
Jack-o-lantern

-=Entities=-
Horse
Horse Armour
Farmer Villager
Double Chests
Double Trapped Chests
Boat
Explosion
Iron Golem
Zombie Pigman

-=GUI=-
Achievements
Inventory
Villager
Anvil enchantment cost

-=Items=-
Banner base
Banner overlay

-=Needs re-formatting=-
Redstone dust
water

-=Missing things that arent noticable=-
//things that havent been copied over due to a change in formatting, but they dont need reformatting due to being the same texture
clock
compass
painting
All particles

-=Missing unused textures=-
Quiver

#Known Bugs#

-Butcher/Leather worker missing hat/head band
-Librarian Hat missing
